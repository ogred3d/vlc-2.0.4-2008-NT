// Version information for the "UsageEnvironment" library
// Copyright (c) 1996-2011 Live Networks, Inc.  All rights reserved.

#ifndef _USAGEENVIRONMENT_VERSION_HH
#define _USAGEENVIRONMENT_VERSION_HH

#define USAGEENVIRONMENT_LIBRARY_VERSION_STRING	"2011.12.23"
#define USAGEENVIRONMENT_LIBRARY_VERSION_INT		1324598400

#endif
